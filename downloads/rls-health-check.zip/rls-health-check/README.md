# RLS Health Check

Four small Python scripts that check Row-Level Security (RLS) in a Power BI semantic model.
They go with the free guide **Who Sees What: a practical guide to Row-Level Security in Power BI**
on [datasanj.com](https://www.datasanj.com/blog-rls-guide.html).

| Script | What it checks | Needs Power BI sign-in? |
|---|---|---|
| `check_1_scan_model.py` | Roles, leaky tables, filter direction, identity functions, RLS + OLS clashes, storage modes | No. Reads your PBIP files |
| `check_2_security_table.py` | Duplicate, blank, mistyped and guest emails; keys missing from the dimension | No. Reads a CSV/Excel |
| `check_3_access_audit.py` | Who can open the workspace, and who bypasses RLS | Yes (read only) |
| `check_4_test_as_users.py` | Runs a DAX query as each test user and compares with what you expect | Yes (read only) |

All four scripts only **read**. None of them change your model, workspace or data.

## Set up (once)

1. Install Python 3.10 or later.
2. Open a terminal in this folder and run:

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
```

## Try it on the sample first

The `sample` folder has a small model with mistakes planted on purpose.

```bash
python check_1_scan_model.py sample/Sales.SemanticModel
python check_2_security_table.py sample/security_table.csv --email Email --key RegionKey --dimension sample/region.csv
```

You should see 4 high findings from check 1 and 6 issues from check 2.

## Run it on your own model

**Check 1.** Save your report as a Power BI Project (File → Save as → `.pbip`), with the TMDL format turned on.
Point the script at the `.SemanticModel` folder:

```bash
python check_1_scan_model.py "C:\Reports\Sales.SemanticModel" --out scan.md
```

**Check 2.** Export your security table to CSV or Excel:

```bash
python check_2_security_table.py security.xlsx --email UserEmail --key RegionKey --dimension regions.csv
```

**Check 3.** Sign in with `az login` first (or the script opens a browser sign-in):

```bash
python check_3_access_audit.py --workspace "Sales - Prod" --security security.csv --email UserEmail --out access.csv
```

Add `--admin` if you are a Fabric admin, to also list semantic model permissions (Write permission bypasses RLS).

**Check 4.** Write a `tests.csv` like `sample/tests.csv`, then:

```bash
python check_4_test_as_users.py --workspace "Sales - Test" --model "Sales" --tests tests.csv
```

This needs the tenant setting *Dataset Execute Queries REST API* turned on and Build permission on the model.
Models with RLS can't be queried with a service principal, so sign in as a person.

## Run the tests

```bash
pip install pytest
python -m pytest tests
```

## Limits

- Check 1 reads model design only. It can't see who is inside a security group or what is in your data.
- Check 1 follows relationships to decide which tables a role filters. It treats date tables as usually safe; check them yourself if they hold anything sensitive.
- Checks 3 and 4 call the Power BI REST API, which has rate limits (Execute Queries: 120 queries a minute per user).

Made by Zohal Zahir, [DATASANJ](https://www.datasanj.com). Free to use and change. No warranty.
