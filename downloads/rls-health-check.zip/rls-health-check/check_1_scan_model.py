"""
RLS Health Check 1: scan a Power BI semantic model for RLS design problems.

Reads a PBIP semantic model folder (TMDL files) or a model.bim file.
It does not connect to Power BI and does not read any data.

What it checks (series part in brackets):
  - Tables each role does not filter: possible leaks            (Parts 1, 2)
  - Security filters that need "both directions"                 (Part 1)
  - Identity functions used, and hard-coded (static) rules       (Parts 5, 7)
  - Users in an RLS-only role and an OLS-only role (visual errors) (Parts 13, 14)
  - Measures using ALL / REMOVEFILTERS (per-user totals)         (Part 11)
  - Storage modes, and DAX that DirectQuery RLS can't run         (Part 15)

Usage:
  python check_1_scan_model.py "path/to/MyReport.SemanticModel"
  python check_1_scan_model.py "path/to/model.bim" --out report.md
"""
import argparse
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

DATE_WORDS = ("date", "calendar", "time")


# ---------- Reading the model -------------------------------------------

def unquote(name):
    name = name.strip()
    if len(name) >= 2 and name[0] == "'" and name[-1] == "'":
        return name[1:-1].replace("''", "'")
    return name


def split_column_ref(ref):
    """'Sales Data'.'Order Date' or Sales.DateKey -> (table, column)."""
    ref = ref.strip()
    m = re.match(r"^('(?:[^']|'')*'|[^.]+)\.(.+)$", ref)
    if not m:
        return ref, ""
    return unquote(m.group(1)), unquote(m.group(2))


def read_blocks(text):
    """Turn TMDL text into (indent, line) pairs, skipping blanks and /// docs."""
    out = []
    for raw in text.splitlines():
        if not raw.strip() or raw.strip().startswith("///"):
            continue
        expanded = raw.replace("    ", "\t")
        indent = len(expanded) - len(expanded.lstrip("\t"))
        out.append((indent, raw.strip()))
    return out


HEADER = re.compile(r"^(\w+)\s+('(?:[^']|'')*'|[^\s=]+)\s*(?:=\s*(.*))?$")


def body_until(lines, i, indent):
    """Lines after line i that are indented deeper than `indent`."""
    j = i + 1
    while j < len(lines) and lines[j][0] > indent:
        j += 1
    return lines[i + 1:j], j


def parse_tmdl(folder):
    definition = folder / "definition" if (folder / "definition").is_dir() else folder
    model = {"tables": {}, "relationships": [], "roles": {}}

    for f in sorted((definition / "tables").glob("*.tmdl")):
        lines = read_blocks(f.read_text(encoding="utf-8-sig"))
        table = None
        for i, (ind, line) in enumerate(lines):
            m = HEADER.match(line)
            if not m:
                continue
            kind, name, expr = m.group(1), unquote(m.group(2)), m.group(3)
            if kind == "table" and ind == 0:
                table = {"name": name, "columns": [], "measures": {}, "modes": set()}
                model["tables"][name] = table
            elif table and kind in ("column", "calculatedColumn"):
                table["columns"].append(name)
            elif table and kind == "measure":
                body, _ = body_until(lines, i, ind)
                parts = [expr or ""] + [l for d, l in body if not re.match(r"^\w+:", l)]
                table["measures"][name] = " ".join(parts)
            elif table and kind == "partition":
                body, _ = body_until(lines, i, ind)
                for _, l in body:
                    mm = re.match(r"^mode:\s*(\w+)", l)
                    if mm:
                        table["modes"].add(mm.group(1).lower())
                if not table["modes"]:
                    table["modes"].add("import")

    rel_file = definition / "relationships.tmdl"
    if rel_file.exists():
        lines = read_blocks(rel_file.read_text(encoding="utf-8-sig"))
        for i, (ind, line) in enumerate(lines):
            if ind == 0 and line.startswith("relationship"):
                body, _ = body_until(lines, i, ind)
                props = {}
                for _, l in body:
                    if ":" in l:
                        k, v = l.split(":", 1)
                        props[k.strip()] = v.strip()
                ft, fc = split_column_ref(props.get("fromColumn", ""))
                tt, tc = split_column_ref(props.get("toColumn", ""))
                model["relationships"].append({
                    "from": ft, "fromColumn": fc, "to": tt, "toColumn": tc,
                    "fromCard": props.get("fromCardinality", "many"),
                    "toCard": props.get("toCardinality", "one"),
                    "cross": props.get("crossFilteringBehavior", "oneDirection"),
                    "security": props.get("securityFilteringBehavior", "oneDirection"),
                    "active": props.get("isActive", "true").lower() != "false",
                })

    for f in sorted((definition / "roles").glob("*.tmdl")):
        lines = read_blocks(f.read_text(encoding="utf-8-sig"))
        role = None
        for i, (ind, line) in enumerate(lines):
            m = HEADER.match(line)
            if not m:
                continue
            kind, name, expr = m.group(1), unquote(m.group(2)), m.group(3)
            if kind == "role" and ind == 0:
                role = {"filters": {}, "hidden_tables": [], "hidden_columns": [], "members": []}
                model["roles"][name] = role
            elif role and kind == "tablePermission":
                body, _ = body_until(lines, i, ind)
                filt = (expr or "").strip()
                in_expr = "=" in line                       # header 'tablePermission X =' starts a rule
                for k, (d, l) in enumerate(body):
                    if l.startswith("columnPermission"):
                        in_expr = False
                        cm = HEADER.match(l)
                        value = (cm.group(3) or "") if cm else ""
                        child = body[k + 1][1] if k + 1 < len(body) and body[k + 1][0] > d else ""
                        if value.lower().strip() == "none" or re.match(r"^metadataPermission:\s*none", child, re.I):
                            role["hidden_columns"].append(f"{name}[{unquote(cm.group(2))}]")
                    elif re.match(r"^metadataPermission:\s*none", l, re.I) and d == ind + 1:
                        role["hidden_tables"].append(name)
                    elif l.startswith("filterExpression"):
                        filt = l.split("=", 1)[1].strip() if "=" in l else filt
                        in_expr = True
                    elif re.match(r"^\w+:", l) or l.startswith("annotation"):
                        in_expr = False
                    elif in_expr:
                        filt = (filt + " " + l).strip()
                if filt:
                    role["filters"][name] = filt.strip("`").strip()
            elif role and kind == "member":
                role["members"].append(name)
    return model


def parse_bim(path):
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    m = data.get("model", data)
    model = {"tables": {}, "relationships": [], "roles": {}}

    def text(x):
        return "\n".join(x) if isinstance(x, list) else (x or "")

    for t in m.get("tables", []):
        modes = {(p.get("mode") or m.get("defaultMode") or "import").lower() for p in t.get("partitions", [])}
        model["tables"][t["name"]] = {
            "name": t["name"],
            "columns": [c["name"] for c in t.get("columns", []) if c.get("type") != "rowNumber"],
            "measures": {x["name"]: text(x.get("expression")) for x in t.get("measures", [])},
            "modes": modes or {"import"},
        }
    for r in m.get("relationships", []):
        model["relationships"].append({
            "from": r["fromTable"], "fromColumn": r["fromColumn"],
            "to": r["toTable"], "toColumn": r["toColumn"],
            "fromCard": r.get("fromCardinality", "many"), "toCard": r.get("toCardinality", "one"),
            "cross": r.get("crossFilteringBehavior", "oneDirection"),
            "security": r.get("securityFilteringBehavior", "oneDirection"),
            "active": r.get("isActive", True),
        })
    for role in m.get("roles", []):
        entry = {"filters": {}, "hidden_tables": [], "hidden_columns": [],
                 "members": [x.get("memberName", "") for x in role.get("members", [])]}
        for tp in role.get("tablePermissions", []):
            if tp.get("filterExpression"):
                entry["filters"][tp["name"]] = text(tp["filterExpression"])
            if str(tp.get("metadataPermission", "")).lower() == "none":
                entry["hidden_tables"].append(tp["name"])
            for cp in tp.get("columnPermissions", []):
                if str(cp.get("metadataPermission", "")).lower() == "none":
                    entry["hidden_columns"].append(f"{tp['name']}[{cp['name']}]")
        model["roles"][role["name"]] = entry
    return model


def load_model(path):
    path = Path(path)
    if path.is_file() and path.suffix.lower() == ".bim":
        return parse_bim(path)
    if path.is_dir():
        bim = path / "model.bim"
        if bim.exists():
            return parse_bim(bim)
        if (path / "definition").is_dir() or (path / "tables").is_dir():
            return parse_tmdl(path)
    sys.exit(f"Could not find TMDL files or model.bim in: {path}")


# ---------- How a security filter travels -------------------------------

def security_edges(rel):
    """Directions a *security* filter can travel across one relationship."""
    if not rel["active"]:
        return []
    one_to_one = rel["fromCard"] == "one" and rel["toCard"] == "one"
    both = rel["cross"] == "bothDirections" and rel["security"] == "bothDirections"
    edges = [(rel["to"], rel["from"])]          # one side -> many side
    if both or one_to_one:
        edges.append((rel["from"], rel["to"]))  # many side -> one side
    return edges


def reached_tables(model, start_tables):
    graph = defaultdict(set)
    for rel in model["relationships"]:
        for a, b in security_edges(rel):
            graph[a].add(b)
    seen, todo = set(start_tables), list(start_tables)
    while todo:
        for nxt in graph[todo.pop()]:
            if nxt not in seen:
                seen.add(nxt)
                todo.append(nxt)
    return seen


# ---------- The checks --------------------------------------------------

def run_checks(model):
    findings = []   # (level, part, message)

    def add(level, part, msg):
        findings.append((level, part, msg))

    tables = model["tables"]
    data_tables = {n for n, t in tables.items() if t["columns"]}
    rls_roles = {n: r for n, r in model["roles"].items() if r["filters"]}
    ols_roles = {n: r for n, r in model["roles"].items() if r["hidden_columns"] or r["hidden_tables"]}

    if not model["roles"]:
        add("HIGH", 1, "The model has no roles. Every user who can open the report sees all rows.")
    for name, role in model["roles"].items():
        if not role["filters"] and not role["hidden_columns"] and not role["hidden_tables"]:
            add("HIGH", 19, f"Role '{name}' has no rules. Its members see every row.")
        elif not role["filters"]:
            add("INFO", 14, f"Role '{name}' only hides columns/tables. Its members still see every row.")

    # Parts 1-2: tables a role does not reach
    for name, role in rls_roles.items():
        blocked = {t for t, f in role["filters"].items() if re.fullmatch(r"\s*FALSE\s*\(\s*\)\s*", f, re.I)}
        reached = reached_tables(model, [t for t in role["filters"] if t not in blocked]) | blocked
        for t in sorted(data_tables - reached - set(role["hidden_tables"])):
            if any(w in t.lower() for w in DATE_WORDS):
                add("INFO", 2, f"Role '{name}': table '{t}' is not filtered (looks like a date table, usually fine).")
            else:
                add("HIGH", 2, f"Role '{name}': table '{t}' is not filtered. Users in this role see ALL its rows. "
                               f"Relate it to a filtered table, or add FALSE() if it is sensitive.")

    # Part 1: filters that start on a bridge/security table but can't climb to the dimension
    for rel in model["relationships"]:
        if rel["cross"] == "bothDirections" and rel["security"] != "bothDirections":
            for name, role in rls_roles.items():
                if rel["from"] in role["filters"]:
                    add("HIGH", 1, f"Relationship {rel['from']} -> {rel['to']} is both-directions, but "
                                   f"'Apply security filter in both directions' is off, so role '{name}' "
                                   f"can't filter '{rel['to']}' from '{rel['from']}'.")
        if rel["fromCard"] == "many" and rel["toCard"] == "many":
            add("MEDIUM", 1, f"Many-to-many relationship {rel['from']} <-> {rel['to']}. "
                             f"Check the security filter direction carefully; a bridge to a unique dimension is safer.")

    # Parts 5 and 7: identity functions and static rules
    for name, role in rls_roles.items():
        all_dax = " ".join(role["filters"].values()).upper()
        if "USERNAME()" in all_dax:
            add("MEDIUM", 5, f"Role '{name}' uses USERNAME(). In Desktop it can return DOMAIN\\user; "
                             f"USERPRINCIPALNAME() is the clearer choice for email matching.")
        if "CUSTOMDATA()" in all_dax:
            add("INFO", 6, f"Role '{name}' uses CUSTOMDATA(). It only has a value in embedded scenarios "
                           f"where the app passes it in the token.")
        dynamic = any(f in all_dax for f in ("USERPRINCIPALNAME()", "USERNAME()", "USEROBJECTID()", "CUSTOMDATA()"))
        if not dynamic and not all(re.fullmatch(r"\s*FALSE\s*\(\s*\)\s*", f, re.I) for f in role["filters"].values()):
            add("INFO", 7, f"Role '{name}' is static (hard-coded values). You need one role per audience "
                           f"and must add members by hand.")

    # Parts 13-14: RLS-only and OLS-only roles side by side
    rls_only = [n for n in rls_roles if n not in ols_roles]
    ols_only = [n for n in ols_roles if n not in rls_roles]
    if rls_only and ols_only:
        add("HIGH", 14, f"RLS-only roles {rls_only} and OLS-only roles {ols_only} both exist. Anyone in one of each "
                        f"gets visual errors. Put both rules in one role for that audience.")
    if len(model["roles"]) > 1:
        add("INFO", 13, "Roles add up (OR). A user in two roles sees the rows of both. Test with every role a person holds.")

    # Part 11: ALL / REMOVEFILTERS in measures
    for t in tables.values():
        for mname, expr in t["measures"].items():
            if re.search(r"\b(ALL|ALLEXCEPT|ALLSELECTED|REMOVEFILTERS)\s*\(", expr, re.I):
                add("INFO", 11, f"Measure [{mname}] uses ALL/REMOVEFILTERS. RLS still applies, so 'total' means "
                                f"'total of the rows this user can see', not the company total.")

    # Part 15: storage modes
    dq = {n for n, t in tables.items() if t["modes"] & {"directquery", "dual"}}
    dl = {n for n, t in tables.items() if "directlake" in t["modes"]}
    if dq:
        add("INFO", 15, f"DirectQuery/Dual tables: {sorted(dq)}. RLS filters become part of every source query; test speed.")
        for name, role in rls_roles.items():
            for t, f in role["filters"].items():
                if t in dq and re.search(r"\b(PATH\w*|CUSTOMDATA)\s*\(", f, re.I):
                    add("HIGH", 15, f"Role '{name}' uses PATH/CUSTOMDATA on DirectQuery table '{t}'. These don't work "
                                    f"in DirectQuery role rules. Use a flat manager-employee table, or pass the ID as "
                                    f"the username when embedding.")
    if dl:
        add("INFO", 15, f"Direct Lake tables: {sorted(dl)}. Check where security lives (model or lakehouse) "
                        f"and whether queries fall back to DirectQuery.")

    # Members saved in the file (Part 3 / 19)
    for name, role in model["roles"].items():
        if role["members"]:
            add("INFO", 19, f"Role '{name}' has members saved in the file: {role['members']}. "
                            f"Prefer security groups, added in the Power BI service.")
    return findings


def report(model, findings):
    order = {"HIGH": 0, "MEDIUM": 1, "INFO": 2}
    lines = ["# RLS model scan", ""]
    lines.append(f"Tables: {len(model['tables'])} | Relationships: {len(model['relationships'])} | "
                 f"Roles: {len(model['roles'])}")
    lines.append("")
    lines.append("## Roles")
    for name, r in model["roles"].items():
        lines.append(f"- **{name}**")
        for t, f in r["filters"].items():
            lines.append(f"  - filter on {t}: `{f}`")
        for c in r["hidden_columns"]:
            lines.append(f"  - hides column {c}")
        for t in r["hidden_tables"]:
            lines.append(f"  - hides table {t}")
    lines.append("")
    counts = {k: sum(1 for f in findings if f[0] == k) for k in order}
    lines.append(f"## Findings: {counts['HIGH']} high, {counts['MEDIUM']} medium, {counts['INFO']} info")
    for level, part, msg in sorted(findings, key=lambda f: (order[f[0]], f[1])):
        lines.append(f"- [{level}] (Part {part}) {msg}")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="Scan a Power BI semantic model for RLS design problems.")
    ap.add_argument("model", help="Path to a .SemanticModel folder, its definition folder, or model.bim")
    ap.add_argument("--out", help="Save the report as a Markdown file")
    args = ap.parse_args()

    model = load_model(args.model)
    findings = run_checks(model)
    text = report(model, findings)
    print(text)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
        print(f"\nSaved: {args.out}")
    sys.exit(1 if any(f[0] == "HIGH" for f in findings) else 0)


if __name__ == "__main__":
    main()
