"""
RLS Health Check 2: check the security table before it goes into the model.

Your RLS rule usually matches the signed-in user's email to a column in a
security table. If an email is mistyped, duplicated or has extra spaces,
that person sees nothing (or the wrong rows). This script finds those rows.

What it checks (series part in brackets):
  - Blank emails or blank keys                                  (Part 1)
  - Emails that aren't valid UPN-style addresses                (Part 5)
  - Extra spaces and mixed case that create silent duplicates   (Part 1)
  - Guest accounts with #EXT# in the UPN                        (Part 4)
  - Keys that don't exist in the dimension (user sees nothing)  (Part 1)

Usage:
  python check_2_security_table.py security.csv --email Email --key RegionKey
  python check_2_security_table.py security.xlsx --email Email --key RegionKey \
         --dimension region.csv --dim-key RegionKey
"""
import argparse
import re
import sys
from pathlib import Path

import pandas as pd

EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$")


def read_table(path):
    path = Path(path)
    if path.suffix.lower() in (".xlsx", ".xls"):
        return pd.read_excel(path, dtype=str)
    return pd.read_csv(path, dtype=str, keep_default_na=False)


def check(security, email_col, key_col, dim=None, dim_key=None):
    issues = []   # (row number in file, email, problem, part)
    df = security.fillna("")
    for col in (email_col, key_col):
        if col not in df.columns:
            sys.exit(f"Column '{col}' not found. Columns are: {list(df.columns)}")

    clean = df[email_col].str.strip().str.lower()
    for i, row in df.iterrows():
        line = i + 2                                  # +1 header, +1 for 1-based rows
        raw, key = row[email_col], str(row[key_col]).strip()
        if not raw.strip():
            issues.append((line, raw, "Blank email", 1))
            continue
        if raw != raw.strip():
            issues.append((line, raw, "Extra spaces around the email; it won't match the signed-in user", 1))
        if "#EXT#" in raw.upper():
            issues.append((line, raw, "Guest UPN with #EXT#. Often USERPRINCIPALNAME() returns the invited "
                                      "email instead; store exactly what a UPN card shows for this guest", 4))
        elif not EMAIL.match(raw.strip()):
            issues.append((line, raw, "Doesn't look like a valid UPN/email", 5))
        if not key:
            issues.append((line, raw, f"Blank {key_col}: this user matches no rows", 1))

    # Same person + same key written differently (case or spaces)
    dup = df.assign(_e=clean, _k=df[key_col].astype(str).str.strip())
    for (_e, _k), group in dup[dup._e != ""].groupby(["_e", "_k"]):
        if len(group) > 1:
            lines = [int(x) + 2 for x in group.index]
            issues.append((lines[0], _e, f"Listed {len(group)} times for {key_col}={_k} (rows {lines}). "
                                         f"Usually a case or spacing copy", 1))

    # Keys missing from the dimension
    if dim is not None:
        valid = set(dim[dim_key].astype(str).str.strip())
        for i, row in df.iterrows():
            key = str(row[key_col]).strip()
            if key and key not in valid:
                issues.append((i + 2, row[email_col], f"{key_col}={key} is not in the dimension; "
                                                      f"this user sees no rows for it", 1))
    return sorted(issues)


def main():
    ap = argparse.ArgumentParser(description="Check an RLS security table for problems.")
    ap.add_argument("file", help="CSV or Excel security table")
    ap.add_argument("--email", required=True, help="Email/UPN column name")
    ap.add_argument("--key", required=True, help="Key column name, e.g. RegionKey")
    ap.add_argument("--dimension", help="Optional CSV/Excel of the dimension (e.g. Region)")
    ap.add_argument("--dim-key", help="Key column in the dimension (defaults to --key)")
    ap.add_argument("--out", help="Save the issues as CSV")
    args = ap.parse_args()

    security = read_table(args.file)
    dim = read_table(args.dimension) if args.dimension else None
    issues = check(security, args.email, args.key, dim, args.dim_key or args.key)

    users = security[args.email].fillna("").str.strip().str.lower()
    print(f"Rows: {len(security)} | Distinct users: {users[users != ''].nunique()} | Issues: {len(issues)}\n")
    for line, email, problem, part in issues:
        print(f"Row {line:>4}  (Part {part})  {email!r}: {problem}")
    if not issues:
        print("No problems found.")
    if args.out:
        pd.DataFrame(issues, columns=["row", "email", "problem", "series_part"]).to_csv(args.out, index=False)
        print(f"\nSaved: {args.out}")
    sys.exit(1 if issues else 0)


if __name__ == "__main__":
    main()
