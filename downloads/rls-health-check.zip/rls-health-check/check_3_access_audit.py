"""
RLS Health Check 3: who can open the workspace, and who skips RLS?

RLS only filters people with Viewer access. Workspace Admins, Members and
Contributors, and anyone with Write permission on the semantic model, see
every row. This script lists everyone and marks who bypasses RLS.

What it checks (series part in brackets):
  - Workspace roles: Admin / Member / Contributor bypass RLS     (Part 3)
  - People added directly instead of through groups              (Parts 17, 19)
  - Guests and apps with access                                  (Parts 4, 6)
  - Optional (Fabric admin only): model permissions, incl. Write (Parts 3, 19)
  - Optional: compares workspace users with your security table  (Part 19)

Sign-in: uses your Azure CLI login if you ran `az login`, otherwise opens
a browser sign-in. It only READS; it changes nothing.

Usage:
  python check_3_access_audit.py --workspace "Sales Reporting"
  python check_3_access_audit.py --workspace "Sales Reporting" --admin \
         --security security.csv --email Email --out access.csv
"""
import argparse
import sys

import pandas as pd
import requests

API = "https://api.powerbi.com/v1.0/myorg"
SCOPE = "https://analysis.windows.net/powerbi/api/.default"
BYPASS_ROLES = {"Admin", "Member", "Contributor"}


def get_token():
    from azure.identity import AzureCliCredential, InteractiveBrowserCredential
    try:
        return AzureCliCredential().get_token(SCOPE).token
    except Exception:
        return InteractiveBrowserCredential().get_token(SCOPE).token


def make_get(token):
    session = requests.Session()
    session.headers["Authorization"] = f"Bearer {token}"

    def get(path):
        r = session.get(f"{API}{path}", timeout=60)
        if r.status_code == 403:
            raise PermissionError(f"403 Forbidden on {path}. You may need Admin/Member access or Fabric admin rights.")
        r.raise_for_status()
        return r.json().get("value", [])
    return get


def find_workspace(get, name):
    matches = [w for w in get("/groups") if w["name"].lower() == name.lower()]
    if not matches:
        sys.exit(f"Workspace '{name}' not found (or you don't have access).")
    return matches[0]


def audit(get, workspace_name, admin=False):
    ws = find_workspace(get, workspace_name)
    rows = []
    for u in get(f"/groups/{ws['id']}/users"):
        role = u.get("groupUserAccessRight", "None")
        rows.append({
            "level": "Workspace",
            "item": ws["name"],
            "name": u.get("displayName", ""),
            "identifier": u.get("emailAddress") or u.get("identifier", ""),
            "principal_type": u.get("principalType", ""),
            "access": role,
            "bypasses_rls": role in BYPASS_ROLES,
        })
    if admin:
        for ds in get(f"/groups/{ws['id']}/datasets"):
            for u in get(f"/admin/datasets/{ds['id']}/users"):
                right = u.get("datasetUserAccessRight", "None")
                rows.append({
                    "level": "Semantic model",
                    "item": ds["name"],
                    "name": u.get("displayName", ""),
                    "identifier": u.get("emailAddress") or u.get("identifier", ""),
                    "principal_type": u.get("principalType", ""),
                    "access": right,
                    "bypasses_rls": "Write" in right,
                })
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    df["is_guest"] = df["identifier"].str.upper().str.contains("#EXT#", na=False)
    return df


def notes(df, security_emails=None):
    out = []
    ws = df[df.level == "Workspace"]
    bypass = df[df.bypasses_rls]
    out.append(f"{len(bypass)} of {len(df)} access entries bypass RLS (see Part 3).")
    for _, r in bypass.iterrows():
        out.append(f"  BYPASS  {r['access']:<24} {r['principal_type']:<6} {r['identifier']}  ({r['level']}: {r['item']})")
    users = ws[(ws.principal_type == "User") & (ws.access == "Viewer")]
    if len(users):
        out.append(f"{len(users)} Viewer(s) added one by one. Groups are easier to keep the same in Dev, Test and Prod (Part 17).")
    if df.is_guest.any():
        out.append(f"{int(df.is_guest.sum())} guest account(s) have access. Test RLS with a real guest (Part 4).")
    if (df.principal_type == "App").any():
        out.append("Apps / service principals have access. Check what identity embedded reports use (Part 6).")
    if security_emails is not None:
        viewers = set(ws[(ws.access == "Viewer") & (ws.principal_type == "User")].identifier.str.lower())
        missing = sorted(v for v in viewers if v and v not in security_emails)
        if missing:
            out.append(f"{len(missing)} Viewer(s) are not in the security table, so they will see no data: {missing}")
        if (ws.principal_type == "Group").any():
            out.append("Groups have access; this script can't see who is inside them. Check group members in Entra.")
    return out


def main():
    ap = argparse.ArgumentParser(description="List who can access a workspace and who bypasses RLS.")
    ap.add_argument("--workspace", required=True, help="Workspace name")
    ap.add_argument("--admin", action="store_true", help="Also read model permissions (needs Fabric admin)")
    ap.add_argument("--security", help="Optional security table (CSV/XLSX) to compare with")
    ap.add_argument("--email", default="Email", help="Email column in the security table")
    ap.add_argument("--out", help="Save the full list as CSV")
    args = ap.parse_args()

    get = make_get(get_token())
    df = audit(get, args.workspace, args.admin)
    if df.empty:
        sys.exit("No access entries returned.")

    emails = None
    if args.security:
        sec = pd.read_excel(args.security, dtype=str) if args.security.endswith(("xlsx", "xls")) \
            else pd.read_csv(args.security, dtype=str)
        emails = set(sec[args.email].dropna().str.strip().str.lower())

    print(df.drop(columns=["is_guest"]).to_string(index=False))
    print()
    print("\n".join(notes(df, emails)))
    if args.out:
        df.to_csv(args.out, index=False)
        print(f"\nSaved: {args.out}")


if __name__ == "__main__":
    main()
