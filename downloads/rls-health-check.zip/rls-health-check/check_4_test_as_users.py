"""
RLS Health Check 4: test the published model as each user, automatically.

"View as" in Desktop runs one person at a time, and it runs as you.
This script runs a DAX query against the published semantic model AS each
test user (impersonation) and compares the result with what you expect.
Run it after every deployment to Test and Prod.

What it checks (series part in brackets):
  - Each user sees the number you expect                        (Parts 1, 12)
  - Users who should see nothing really see nothing             (Parts 2, 4)
  - The same tests pass in Dev, Test and Prod                   (Part 17)

Your test file (CSV) has one row per test:

  user,dax,expected
  bob@contoso.com,"EVALUATE ROW(""v"", [Total Sales])",11400
  carol@contoso.com,"EVALUATE ROW(""v"", COUNTROWS(Sales))",>0
  guest@partner.com,"EVALUATE ROW(""v"", COUNTROWS(Sales))",blank

  expected can be a number, >0, 0, or blank (no rows / blank value).

Needs: the tenant setting "Dataset Execute Queries REST API" turned on,
and Build permission on the model for the account you sign in with.
Models with RLS can't be tested with a service principal; sign in as a
person. It only READS data.

Usage:
  python check_4_test_as_users.py --workspace "Sales - Test" --model "Sales" --tests tests.csv
"""
import argparse
import sys

import pandas as pd
import requests

API = "https://api.powerbi.com/v1.0/myorg"
SCOPE = "https://analysis.windows.net/powerbi/api/.default"


def get_token():
    from azure.identity import AzureCliCredential, InteractiveBrowserCredential
    try:
        return AzureCliCredential().get_token(SCOPE).token
    except Exception:
        return InteractiveBrowserCredential().get_token(SCOPE).token


class PowerBI:
    def __init__(self, token, session=None):
        self.s = session or requests.Session()
        self.s.headers["Authorization"] = f"Bearer {token}"

    def get(self, path):
        r = self.s.get(f"{API}{path}", timeout=60)
        r.raise_for_status()
        return r.json().get("value", [])

    def ids(self, workspace, model):
        ws = next((w for w in self.get("/groups") if w["name"].lower() == workspace.lower()), None)
        if not ws:
            sys.exit(f"Workspace '{workspace}' not found.")
        ds = next((d for d in self.get(f"/groups/{ws['id']}/datasets") if d["name"].lower() == model.lower()), None)
        if not ds:
            sys.exit(f"Semantic model '{model}' not found in '{workspace}'.")
        return ws["id"], ds["id"]

    def query_as(self, ws_id, ds_id, dax, user):
        body = {"queries": [{"query": dax}], "serializerSettings": {"includeNulls": True},
                "impersonatedUserName": user}
        r = self.s.post(f"{API}/groups/{ws_id}/datasets/{ds_id}/executeQueries", json=body, timeout=120)
        if r.status_code != 200:
            return None, f"HTTP {r.status_code}: {r.text[:200]}"
        result = r.json()["results"][0]
        if "error" in result:
            return None, str(result["error"])
        rows = result["tables"][0].get("rows", [])
        if not rows:
            return None, None                     # no rows = sees nothing
        return next(iter(rows[0].values())), None


def passes(value, expected):
    expected = str(expected).strip().lower()
    if expected == "blank":
        return value in (None, "", 0)
    if value is None:
        return expected == "0"
    if expected == ">0":
        return float(value) > 0
    return abs(float(value) - float(expected)) < 0.005


def run(pbi, ws_id, ds_id, tests):
    results = []
    for _, t in tests.iterrows():
        value, error = pbi.query_as(ws_id, ds_id, t["dax"], t["user"])
        ok = error is None and passes(value, t["expected"])
        results.append({"user": t["user"], "expected": t["expected"],
                        "got": "(no rows)" if value is None else value,
                        "result": "PASS" if ok else "FAIL", "error": error or ""})
    return pd.DataFrame(results)


def main():
    ap = argparse.ArgumentParser(description="Test RLS as each user against a published model.")
    ap.add_argument("--workspace", required=True)
    ap.add_argument("--model", required=True, help="Semantic model name")
    ap.add_argument("--tests", required=True, help="CSV with columns user, dax, expected")
    ap.add_argument("--out", help="Save results as CSV")
    args = ap.parse_args()

    tests = pd.read_csv(args.tests, dtype=str)
    pbi = PowerBI(get_token())
    ws_id, ds_id = pbi.ids(args.workspace, args.model)
    df = run(pbi, ws_id, ds_id, tests)

    print(df.to_string(index=False))
    failed = int((df.result == "FAIL").sum())
    print(f"\n{len(df) - failed} passed, {failed} failed.")
    if args.out:
        df.to_csv(args.out, index=False)
        print(f"Saved: {args.out}")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
