"""Offline tests. Run with:  python -m pytest tests"""
import importlib.util
import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SAMPLE = ROOT / "sample"


def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


scan = load("check_1_scan_model")
sec = load("check_2_security_table")
audit = load("check_3_access_audit")
tester = load("check_4_test_as_users")


def msgs(findings, level=None):
    return [m for lv, _, m in findings if level is None or lv == level]


# ---- Check 1 ----
def test_tmdl_parses_roles_and_relationships():
    m = scan.load_model(SAMPLE / "Sales.SemanticModel")
    assert set(m["roles"]) == {"Regional Sales", "Hide Salary", "North Static"}
    assert m["roles"]["Hide Salary"]["hidden_columns"] == ["Employees[Salary]"]
    assert m["roles"]["Regional Sales"]["members"] == ["alice@contoso.com"]
    assert len(m["relationships"]) == 5
    assert m["tables"]["Sales"]["modes"] == {"directquery"}


def test_leaks_found_and_bridge_works():
    f = scan.run_checks(scan.load_model(SAMPLE / "Sales.SemanticModel"))
    high = " ".join(msgs(f, "HIGH"))
    assert "'Regional Sales': table 'Targets'" in high
    assert "'Regional Sales': table 'KPI_Summary'" in high
    assert "'North Static': table 'KPI_Summary'" not in high     # FALSE() counts
    assert "table 'Sales' is not filtered" not in high          # reached through bridge
    assert "table 'Employees' is not filtered" not in high
    assert "OLS-only roles" in high


def test_security_filter_direction_off_is_a_leak():
    m = scan.load_model(SAMPLE / "Sales.SemanticModel")
    m["relationships"][0]["security"] = "oneDirection"
    f = scan.run_checks(m)
    assert any("'Apply security filter in both directions' is off" in x for x in msgs(f, "HIGH"))
    assert any("'Regional Sales': table 'Sales' is not filtered" in x for x in msgs(f, "HIGH"))


def test_model_bim_and_directquery_path(tmp_path):
    bim = {"model": {
        "tables": [
            {"name": "Employees", "columns": [{"name": "Email"}, {"name": "Path"}],
             "partitions": [{"name": "p", "mode": "directQuery"}]},
            {"name": "Sales", "columns": [{"name": "EmpID"}],
             "measures": [{"name": "Total", "expression": "SUM(Sales[Amt])"}],
             "partitions": [{"name": "p", "mode": "import"}]}],
        "relationships": [{"name": "r", "fromTable": "Sales", "fromColumn": "EmpID",
                           "toTable": "Employees", "toColumn": "EmpID"}],
        "roles": [{"name": "Managers", "modelPermission": "read", "tablePermissions": [
            {"name": "Employees", "filterExpression":
                "PATHCONTAINS(Employees[Path], LOOKUPVALUE(Employees[EmpID], Employees[Email], USERPRINCIPALNAME()))"}]},
            {"name": "Empty", "modelPermission": "read"}]}}
    p = tmp_path / "model.bim"
    p.write_text(json.dumps(bim))
    f = scan.run_checks(scan.load_model(p))
    high = " ".join(msgs(f, "HIGH"))
    assert "PATH/CUSTOMDATA on DirectQuery table 'Employees'" in high
    assert "Role 'Empty' has no rules" in high
    assert not any("is not filtered" in x for x in msgs(f, "HIGH"))


def test_multiline_and_quoted_tmdl(tmp_path):
    d = tmp_path / "M.SemanticModel" / "definition"
    (d / "tables").mkdir(parents=True)
    (d / "roles").mkdir()
    (d / "tables" / "t.tmdl").write_text("table 'Sales Data'\n\tcolumn 'Region Name'\n\t\tdataType: string\n")
    (d / "roles" / "r.tmdl").write_text(
        "role 'East Team'\n\tmodelPermission: read\n\n\ttablePermission 'Sales Data' =\n"
        "\t\t\t[Region Name] = \"East\"\n\t\t\t|| [Region Name] = \"North\"\n")
    m = scan.load_model(tmp_path / "M.SemanticModel")
    assert m["roles"]["East Team"]["filters"]["Sales Data"].startswith('[Region Name] = "East"')
    assert "North" in m["roles"]["East Team"]["filters"]["Sales Data"]


# ---- Check 2 ----
def test_security_table_issues():
    s = sec.read_table(SAMPLE / "security_table.csv")
    d = sec.read_table(SAMPLE / "region.csv")
    issues = sec.check(s, "Email", "RegionKey", d, "RegionKey")
    problems = " | ".join(p for _, _, p, _ in issues)
    for text in ("Listed 2 times", "Extra spaces", "#EXT#", "valid UPN", "Blank RegionKey", "not in the dimension"):
        assert text in problems
    assert len(issues) == 6


# ---- Check 3 (fake API) ----
FAKE = {
    "/groups": [{"id": "w1", "name": "Sales Reporting"}],
    "/groups/w1/users": [
        {"displayName": "Zohal", "emailAddress": "z@contoso.com", "principalType": "User", "groupUserAccessRight": "Admin"},
        {"displayName": "Bob", "emailAddress": "bob@contoso.com", "principalType": "User", "groupUserAccessRight": "Contributor"},
        {"displayName": "Carol", "emailAddress": "carol@contoso.com", "principalType": "User", "groupUserAccessRight": "Viewer"},
        {"displayName": "Guest", "identifier": "g_x.com#EXT#@contoso.onmicrosoft.com", "principalType": "User", "groupUserAccessRight": "Viewer"},
        {"displayName": "Sales Team", "identifier": "abc", "principalType": "Group", "groupUserAccessRight": "Viewer"}],
    "/groups/w1/datasets": [{"id": "d1", "name": "Sales"}],
    "/admin/datasets/d1/users": [
        {"displayName": "Dan", "emailAddress": "dan@contoso.com", "principalType": "User", "datasetUserAccessRight": "ReadWriteExplore"},
        {"displayName": "Eve", "emailAddress": "eve@contoso.com", "principalType": "User", "datasetUserAccessRight": "ReadExplore"}],
}


def test_access_audit_flags_bypass():
    df = audit.audit(lambda p: FAKE[p], "sales reporting", admin=True)
    bypass = set(df[df.bypasses_rls].identifier)
    assert bypass == {"z@contoso.com", "bob@contoso.com", "dan@contoso.com"}
    text = "\n".join(audit.notes(df, {"carol@contoso.com"}))
    assert "3 of 7 access entries bypass RLS" in text
    assert "guest" in text and "not in the security table" in text
    assert "g_x.com#ext#@contoso.onmicrosoft.com" in text


# ---- Check 4 (fake API) ----
class FakeResp:
    def __init__(self, code, data):
        self.status_code, self._d, self.text = code, data, json.dumps(data)

    def json(self):
        return self._d

    def raise_for_status(self):
        pass


class FakeSession:
    headers = {}
    VALUES = {"bob@contoso.com": 11400, "carol@contoso.com": 3700}

    def get(self, url, timeout=0):
        path = url.split("/myorg")[1]
        return FakeResp(200, {"value": {"/groups": [{"id": "w", "name": "Sales - Test"}],
                                        "/groups/w/datasets": [{"id": "d", "name": "Sales"}]}[path]})

    def post(self, url, json=None, timeout=0):
        assert json["impersonatedUserName"]
        v = self.VALUES.get(json["impersonatedUserName"])
        rows = [] if v is None else [{"[v]": v}]
        return FakeResp(200, {"results": [{"tables": [{"rows": rows}]}]})


def test_impersonation_pass_fail():
    pbi = tester.PowerBI("t", FakeSession())
    ws, ds = pbi.ids("Sales - Test", "Sales")
    tests = pd.read_csv(SAMPLE / "tests.csv", dtype=str)
    df = tester.run(pbi, ws, ds, tests)
    assert list(df.result) == ["PASS", "PASS", "PASS"]
    tests.loc[0, "expected"] = "9999"
    assert tester.run(pbi, ws, ds, tests).result.tolist()[0] == "FAIL"
